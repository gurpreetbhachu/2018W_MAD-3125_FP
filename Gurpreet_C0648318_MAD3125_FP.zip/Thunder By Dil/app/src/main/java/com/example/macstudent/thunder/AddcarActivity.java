package com.example.macstudent.thunder;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class AddcarActivity extends AppCompatActivity implements View.OnClickListener{

    Button btnSubmit;
    EditText txtcarcompany;
    EditText txtcarname;
    EditText txtcarplate;
    DBHelper dbHelper;
    SQLiteDatabase ParkDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addcar);

        btnSubmit = (Button)findViewById(R.id.btnSubmit);
        btnSubmit.setOnClickListener(this);

        txtcarcompany = (EditText) findViewById(R.id.txtCarCompany);
        txtcarname = (EditText) findViewById(R.id.txtCarName);
        txtcarplate = (EditText) findViewById(R.id.txtCarPlate);

        dbHelper = new DBHelper(this);
    }

    @Override
    public void onBackPressed() {
        finish();
        Intent supportIntent = new Intent(this, HomeActivity.class);
        startActivity(supportIntent);
    }

    @Override
    public void onClick(View view) {

        if(view.getId() == btnSubmit.getId())
        {

            if(txtcarplate.getText().toString().length() == 0 || txtcarname.getText().toString().length() == 0 || txtcarname.getText().toString().length() == 0)
            {
                Toast.makeText(this,"Please fill all detail",Toast.LENGTH_LONG).show();
            }
            else {
                insertUser();
                finish();
                Intent supportIntent = new Intent(this, HomeActivity.class);
                startActivity(supportIntent);
            }

        }

    }

    private void insertUser()
    {
        EditText Car_Company = (EditText)findViewById(R.id.txtCarCompany);
        EditText Car_Name = (EditText)findViewById(R.id.txtCarName);
        EditText Car_Plate = (EditText)findViewById(R.id.txtCarPlate);

        String company = Car_Company.getText().toString();
        String car = Car_Name.getText().toString();
        String plate = Car_Plate.getText().toString();

        ContentValues cv = new ContentValues();
        cv.put("CarCompany", company);
        cv.put("CarName",car);
        cv.put("CarPlate",plate);

        try
        {
            ParkDB = dbHelper.getWritableDatabase();
            ParkDB.insert(dbHelper.TB_NAME_CARS,null,cv);
            // Log.e("Insert User", "Success");


            Toast.makeText(this,"Car Detail Saved",Toast.LENGTH_LONG).show();

        }
        catch(Exception e)
        {
            Log.e("Insert Car",e.getMessage());
        }
        ParkDB.close();
    }
}
