package com.example.macstudent.thunder;

/**
 * Created by macstudent on 2018-04-16.
 */

public class GlobalVariable {
    public final static String TB_NAME_CARS = "CarsDetail";
    public static String[] companies = {};
    public static String[] amounts = {};
    public static String[] lots = {};
    public static String[] spots = {};
    public static String[] datetimes  = {};
    public static String[] carPlates = {} ;
    public static Double[] lat = {43.778486,43.778486, 43.778486};
    public static Double[] lang = {-79.3983048,-79.4732005, -79.4734005, -79.4732560};
    public static Integer parkTime = 0;
    public static String[] userfname = {"gs","kuljeet","dilpreet"};
    public static String[] useremail = {"gs@gmail.com","ks","ds"};

}
