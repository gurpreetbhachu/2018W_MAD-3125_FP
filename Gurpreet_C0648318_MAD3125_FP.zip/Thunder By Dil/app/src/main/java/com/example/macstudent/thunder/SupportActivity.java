package com.example.macstudent.thunder;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class SupportActivity extends AppCompatActivity implements View.OnClickListener {

    Button btnSubmit;
    TextView txtmsg;
    TextView txtName;
    TextView txtPhone;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_support);

        btnSubmit = (Button) findViewById(R.id.btnSubmit);
        btnSubmit.setOnClickListener(this);
        txtmsg = (TextView) findViewById(R.id.txtmsg);
        txtmsg.setOnClickListener(this);

        txtName = (TextView) findViewById(R.id.txtName);
        txtName.setOnClickListener(this);

        txtPhone = (TextView) findViewById(R.id.txtPhone);
        txtPhone.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if(view.getId() == btnSubmit.getId())
        {
            final Intent emailIntent = new Intent(android.content.Intent.ACTION_SEND);

/* Fill it with Data */
            emailIntent.setType("plain/text");
            emailIntent.putExtra(android.content.Intent.EXTRA_EMAIL, new String[]{"support@parkhunter.com"});
            emailIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "Customer Enquiry");
            emailIntent.putExtra(android.content.Intent.EXTRA_TEXT, "Name: "+ txtName.getText().toString() + "\nPhone: "+ txtPhone.getText().toString() +"\n" +txtmsg.getText().toString());

/* Send it off to the Activity-Chooser */
            startActivity(Intent.createChooser(emailIntent, "Send mail..."));

        }
    }

    @Override
    public void onBackPressed() {
        finish();
        Intent supportIntent = new Intent(this, HomeActivity.class);
        startActivity(supportIntent);
    }
}
