package com.example.macstudent.thunder;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;

/**
 * Created by macstudent on 2018-04-06.
 */

public class DBHelper extends SQLiteOpenHelper {

   public final static String DB_NAME = "ParkDB";
   public final static String TB_NAME_USER = "UserInfo";
    public final static String TB_NAME_CARS = "CarsDetail";

    public DBHelper(Context context) {
        super(context, DB_NAME, null, 1);

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        try {

            String CREATE_TABLE="CREATE TABLE " + TB_NAME_USER + "(Id INTEGER  ,"+"Name VARCHAR(100),Phone VARCHAR(20),"+"Email VARCHAR(100) PRIMARY KEY,"+"Password VARCHAR(30),"+ "DOB VARCHAR(10))";
            Log.v("On create table : ",CREATE_TABLE);
            db.execSQL(CREATE_TABLE);

            String CREATE_TABLE2="CREATE TABLE " + TB_NAME_CARS + "(Id INTEGER  ,"+"CarCompany VARCHAR(100),CarName VARCHAR(20),"+"CarPlate VARCHAR(100) PRIMARY KEY)";
            Log.v("On create table : ",CREATE_TABLE2);
            db.execSQL(CREATE_TABLE2);

        }catch(Exception e){
            Log.e("DBHelper",e.getMessage());

        }


    }



    @Override
    public void onUpgrade(SQLiteDatabase db, int olderVersion, int newerVersion) {
        try {
            db.execSQL("DROP TABLE IF EXISTS " + TB_NAME_USER);
            db.execSQL("DROP TABLE IF EXISTS " + TB_NAME_CARS);
            onCreate(db);
        }catch(Exception e){
            Log.e("DBHelper",e.getMessage());

        }
    }
}
