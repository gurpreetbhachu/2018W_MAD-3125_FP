package com.example.macstudent.thunder;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class UserActivity extends AppCompatActivity {
    TextView txtUserInfo;
    TextView txtemail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user);

        txtUserInfo = (TextView) findViewById(R.id.txtUserinfo);
        txtemail = (TextView) findViewById(R.id.txtemail);

        txtUserInfo.setText(GlobalVariable.userfname[0]);
        txtemail.setText(GlobalVariable.useremail[0]);
    }
}
