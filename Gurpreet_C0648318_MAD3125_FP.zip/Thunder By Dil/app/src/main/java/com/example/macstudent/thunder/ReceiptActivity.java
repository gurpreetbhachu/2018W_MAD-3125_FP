package com.example.macstudent.thunder;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

public class ReceiptActivity extends AppCompatActivity {
ListView receiptList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receipt);

        receiptList = (ListView) findViewById(R.id.list_receipt);
        receiptList.setAdapter(new ReportAdapter(getApplicationContext()));
    }

    @Override
    public void onBackPressed() {
        finish();
        Intent supportIntent = new Intent(this, HomeActivity.class);
        startActivity(supportIntent);
    }
}
