package com.example.macstudent.thunder;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;

public class ManualActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manual);

        WebView webManual = (WebView) findViewById(R.id.webView);
        webManual.getSettings().setJavaScriptEnabled(true);
        webManual.getSettings().setLoadWithOverviewMode(true);
        webManual.getSettings().setDomStorageEnabled(true);
        webManual.loadUrl("file:///android_asset/team.html");

    }

    @Override
    public void onBackPressed() {
        finish();
        Intent supportIntent = new Intent(this, HomeActivity.class);
        startActivity(supportIntent);
    }

}
